/* Neutral Creation Operator Loop Engine
   Deterministic test harness for P97 whole-electron continuity closure.
   This is a mathematical/topological model, not a physical antimatter claim. */
(function(global){
  'use strict';
  const TWO_PI = Math.PI * 2;

  function hashString(str){
    let h = 2166136261 >>> 0;
    for(let i=0;i<str.length;i++){
      h ^= str.charCodeAt(i);
      h = Math.imul(h, 16777619);
    }
    return h >>> 0;
  }
  function mulberry32(a){
    return function(){
      let t = a += 0x6D2B79F5;
      t = Math.imul(t ^ t >>> 15, t | 1);
      t ^= t + Math.imul(t ^ t >>> 7, t | 61);
      return ((t ^ t >>> 14) >>> 0) / 4294967296;
    };
  }
  function seeded(seed,key=''){ return mulberry32(hashString(seed + '|' + key)); }
  function clamp(v,a,b){ return Math.max(a, Math.min(b,v)); }

  function buildLoopState(geometry, seed){
    const rng = seeded(seed, 'nco-whole-electron-loop');
    const points = geometry.points.map(p => ({...p}));
    // Integer mode rates make a deterministic exact lap at t = 1.0 in normalized loop time.
    for(const p of points){
      const rr = seeded(seed, 'point|' + p.id);
      p.phase = TWO_PI * rr();
      p.mode = 1 + Math.floor(rr() * 12);
      p.depth = 0.55 + rr() * 0.9;
      p.dark = 0.2 + rr() * 1.8;
      p.light = 0.2 + rr() * 1.8;
      p.chiral = (rr() < 0.5 ? -1 : 1) * (0.35 + rr() * 0.65);
      p.mass = 0.5 + rr();
    }
    return { seed, points, geometry, lap: 1.0, threshold: 0.18, omegaBase: TWO_PI };
  }

  function alphaEnvelope(t, halfLifeT=0.22, pumpPeriod=1.0){
    const cycle = ((t % pumpPeriod) + pumpPeriod) % pumpPeriod;
    const epoch = Math.floor(t / pumpPeriod);
    const growth = 1 - Math.pow(2, -cycle / halfLifeT);
    const pump = Math.pow(Math.sin(Math.PI * cycle / pumpPeriod), 2);
    return { growth, pump, alpha: growth * pump, cycle, epoch };
  }

  function complexMatter(p,t){
    const a = TWO_PI * p.mode * t + p.phase;
    return { re: p.mass * Math.cos(a), im: p.mass * Math.sin(a) };
  }
  function conj(z){ return {re:z.re, im:-z.im}; }
  function mag2(z){ return z.re*z.re + z.im*z.im; }
  function addc(a,b){ return {re:a.re+b.re, im:a.im+b.im}; }
  function muls(z,s){ return {re:z.re*s, im:z.im*s}; }

  function evaluate(state,t, opts={}){
    const halfLifeT = opts.halfLifeT || 0.22;
    const pumpPeriod = opts.pumpPeriod || 1.0;
    const omegaDark = opts.omegaDark || 1.61803398875;
    const e = alphaEnvelope(t, halfLifeT, pumpPeriod);
    const pmap = new Map(state.points.map(p => [p.id,p]));
    const raw = [];
    let sumMag = 0;
    for(const p of state.points){
      const op = pmap.get(p.opposite);
      const M = complexMatter(p,t);
      const anti = conj(complexMatter(op,t));
      const pre = addc(M, muls(anti, e.alpha));
      const direct = mag2(M);
      const inverse = mag2(anti) * e.alpha * e.alpha;
      const balance = clamp(1 - Math.abs(direct - inverse) / Math.max(direct + inverse, 1e-12), 0, 1);
      const shade = (omegaDark * p.dark) / (omegaDark * p.dark + p.light);
      const cycle = e.cycle;
      const depletion = (1 - Math.pow(2, -cycle/halfLifeT)) * Math.pow(2, -cycle/halfLifeT);
      const chirality = Math.abs(p.chiral) * (0.5 + 0.5 * Math.sin(TWO_PI * t + p.phase));
      const nco = balance * shade * depletion * chirality;
      const mag = mag2(pre);
      sumMag += mag;
      raw.push({id:p.id, opposite:p.opposite, x:p.x, y:p.y, kind:p.kind, M, anti, pre, direct, inverse, balance, shade, depletion, chirality, nco, mag});
    }
    const nodes = raw.map(n => ({...n, norm: n.mag / Math.max(sumMag, 1e-12)}));
    const neutralMean = nodes.reduce((a,n)=>a+n.balance,0)/nodes.length;
    const shadeMean = nodes.reduce((a,n)=>a+n.shade,0)/nodes.length;
    const creationMean = nodes.reduce((a,n)=>a+n.nco,0)/nodes.length;
    const creationPeak = nodes.reduce((a,n)=>Math.max(a,n.nco),0);
    return { t, envelope:e, sumMag, normalizedSum:nodes.reduce((a,n)=>a+n.norm,0), neutralMean, shadeMean, creationMean, creationPeak, nodes };
  }

  function closureReport(state, samples=97){
    let maxErr = 0, rms = 0, count = 0;
    for(let i=0;i<samples;i++){
      const t = i / samples;
      const a = evaluate(state,t);
      const b = evaluate(state,t + state.lap);
      for(let j=0;j<a.nodes.length;j++){
        const da = a.nodes[j].norm - b.nodes[j].norm;
        const err = Math.abs(da);
        maxErr = Math.max(maxErr, err);
        rms += da*da; count++;
      }
    }
    rms = Math.sqrt(rms / Math.max(1,count));
    return {lap:state.lap, samples, maxClosureError:maxErr, rmsClosureError:rms, pass:maxErr < 1e-10};
  }

  function elementLikeOccupancy(state, count=24){
    // Model-level element-like states: stable integer occupancy buckets from whole-loop modes.
    const buckets = new Map();
    for(const p of state.points){
      const key = p.mode;
      buckets.set(key, (buckets.get(key)||0) + 1);
    }
    const modes = [...buckets.entries()].sort((a,b)=>a[0]-b[0]);
    const out = [];
    let Z = 0;
    for(const [mode,cap] of modes){
      for(let n=1;n<=cap && out.length<count;n++){
        Z++;
        out.push({Z, mode, shellFill:n, shellCapacity:cap, label:'E'+String(Z).padStart(2,'0')});
      }
      if(out.length>=count) break;
    }
    return out;
  }

  async function sha256Hex(obj){
    const text = typeof obj === 'string' ? obj : JSON.stringify(obj);
    if(global.crypto && crypto.subtle){
      const enc = new TextEncoder().encode(text);
      const buf = await crypto.subtle.digest('SHA-256', enc);
      return [...new Uint8Array(buf)].map(b=>b.toString(16).padStart(2,'0')).join('');
    }
    // fallback not cryptographic, for old file:// browsers only
    return 'fnv32-' + hashString(text).toString(16).padStart(8,'0');
  }

  global.NCOLoopEngine = { hashString, seeded, buildLoopState, evaluate, closureReport, elementLikeOccupancy, sha256Hex };
})(window);
