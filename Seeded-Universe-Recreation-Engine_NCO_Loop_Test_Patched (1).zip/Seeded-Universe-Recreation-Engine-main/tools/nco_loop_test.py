#!/usr/bin/env python3
"""SURE Neutral Creation Operator loop test.
Validates the whole-electron continuity loop over the exact P97 topology.
This is a deterministic mathematical/topological test, not a physical antimatter claim.
"""
from __future__ import annotations
from fractions import Fraction
from itertools import combinations
from dataclasses import dataclass
import argparse, hashlib, json, math

TWO_PI = math.pi * 2

def det(a,b): return a[0]*b[1]-a[1]*b[0]
def sub(a,b): return (a[0]-b[0],a[1]-b[1])
def add(a,b): return (a[0]+b[0],a[1]+b[1])
def mul(a,s): return (a[0]*s,a[1]*s)
def seg_inter(p,p2,q,q2):
    r=sub(p2,p); s=sub(q2,q); den=det(r,s)
    if den == 0: return None
    qmp=sub(q,p); t=det(qmp,s)/den; u=det(qmp,r)/den
    if Fraction(0) <= t <= Fraction(1) and Fraction(0) <= u <= Fraction(1): return add(p,mul(r,t))
    return None

def hash32(s):
    h=2166136261
    for ch in s:
        h ^= ord(ch); h = (h * 16777619) & 0xffffffff
    return h

def rand01(seed,key):
    # deterministic simple PRNG draw stream from keyed hash
    x = hash32(seed+'|'+key)
    x = (x + 0x6D2B79F5) & 0xffffffff
    t = x
    t = (t ^ (t >> 15)) * (t | 1) & 0xffffffff
    t ^= (t + ((t ^ (t >> 7)) * (t | 61) & 0xffffffff)) & 0xffffffff
    return ((t ^ (t >> 14)) & 0xffffffff) / 4294967296

def geometry():
    dirs=[(2,0),(1,1),(-1,1),(-2,0),(-1,-1),(1,-1)]
    V=[(Fraction(0),Fraction(0))]+[(Fraction(x),Fraction(y)) for x,y in dirs]+[(Fraction(2*x),Fraction(2*y)) for x,y in dirs]
    segs=list(combinations(range(len(V)),2)); pts=set(V)
    for (a,b),(c,d) in combinations(segs,2):
        p=seg_inter(V[a],V[b],V[c],V[d])
        if p is not None: pts.add(p)
    def r2(p): X,Y=p; return (X*X+3*Y*Y)/4
    def xy(p): X,Y=p; return float(X/2), float(Y*math.sqrt(3)/2)
    def ang(p): x,y=xy(p); return math.atan2(y,x)
    pts=sorted(pts,key=lambda p:(float(r2(p)),ang(p),float(p[0]),float(p[1])))
    pid={p:i+1 for i,p in enumerate(pts)}
    opp={pid[p]:pid[(-p[0],-p[1])] for p in pts}
    return pts, opp

@dataclass
class Node:
    id:int; x:float; y:float; opposite:int; phase:float; mode:int; dark:float; light:float; chiral:float; mass:float

def build(seed):
    pts, opp = geometry()
    nodes=[]
    for p in pts:
        i=len(nodes)+1; X,Y=p; x=float(X/2); y=float(Y*math.sqrt(3)/2)
        r=lambda k: rand01(seed,f'point|{i}|{k}')
        nodes.append(Node(i,x,y,opp[i],TWO_PI*r('phase'),1+int(r('mode')*12),0.2+r('dark')*1.8,0.2+r('light')*1.8,( -1 if r('sign')<.5 else 1)*(0.35+r('chiral')*.65),0.5+r('mass')))
    return nodes

def alpha(t,half=.22,period=1.0):
    cycle = t % period
    growth = 1 - 2**(-cycle/half)
    pump = math.sin(math.pi*cycle/period)**2
    return growth*pump

def cmatter(n,t):
    a=TWO_PI*n.mode*t+n.phase
    return complex(n.mass*math.cos(a),n.mass*math.sin(a))

def evaluate(nodes,t):
    amap={n.id:n for n in nodes}; a=alpha(t); mags=[]; metrics=[]
    for n in nodes:
        op=amap[n.opposite]
        M=cmatter(n,t); A=cmatter(op,t).conjugate(); pre=M+a*A
        direct=abs(M)**2; inverse=abs(A*a)**2
        balance=max(0,min(1,1-abs(direct-inverse)/max(direct+inverse,1e-12)))
        shade=(1.61803398875*n.dark)/(1.61803398875*n.dark+n.light)
        cycle = t % 1.0
        depletion=(1-2**(-cycle/.22))*2**(-cycle/.22)
        chirality=abs(n.chiral)*(0.5+0.5*math.sin(TWO_PI*t+n.phase))
        nco=balance*shade*depletion*chirality
        mags.append(abs(pre)**2); metrics.append((balance,shade,nco))
    s=sum(mags); norm=[m/s for m in mags]
    return norm, metrics

def closure(nodes,samples):
    mx=0.0; rms=0.0; c=0
    for k in range(samples):
        t=k/samples; a,_=evaluate(nodes,t); b,_=evaluate(nodes,t+1.0)
        for x,y in zip(a,b):
            d=x-y; mx=max(mx,abs(d)); rms+=d*d; c+=1
    return mx, math.sqrt(rms/max(1,c))

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--seed',default='GARY-UNIVERSE-001')
    ap.add_argument('--samples',type=int,default=97)
    ap.add_argument('--json',action='store_true')
    args=ap.parse_args()
    nodes=build(args.seed)
    mx,rms=closure(nodes,args.samples)
    norm,metrics=evaluate(nodes,0.37)
    out={'seed':args.seed,'P97':len(nodes),'opposite_pairs':48,'lap':1.0,'closure_max_error':mx,'closure_rms_error':rms,'pass':mx<1e-10,'normalized_sum':sum(norm),'neutral_mean':sum(m[0] for m in metrics)/len(metrics),'creation_peak':max(m[2] for m in metrics)}
    out['receipt_sha256']=hashlib.sha256(json.dumps(out,sort_keys=True).encode()).hexdigest()
    if args.json: print(json.dumps(out,indent=2))
    else:
        for k,v in out.items(): print(f'{k}: {v}')
if __name__=='__main__': main()
