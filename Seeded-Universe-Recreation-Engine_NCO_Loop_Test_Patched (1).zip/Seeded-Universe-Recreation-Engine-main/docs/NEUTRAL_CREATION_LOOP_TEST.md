# Neutral Creation Operator Loop Test

This document adds a concrete test loop to SURE for the Neutral Creation Operator / Whole Electron Continuity model.

The test is deterministic and seed-rooted. It does not claim to generate physical electrons, antimatter, dark photons, or real chemical elements. It tests whether the symbolic/topological loop closes consistently over the exact P97 Metatron/Fruit topology.

## Core formula under test

```text
C(p,t) = H(B(p,t) S(p,t) E_T(t) |kappa(p,t)| - tau)
         * Normalize[M(p,t) + alpha(t) M(-p,t)*]
```

Where:

```text
P97              = 97 topology nodes from K13 Metatron back-mapping
R(p) = -p        = anti-space reflection / opposite-sync map
M(p,t)           = matter-side truth-source flow
M(-p,t)*         = center-reflected anti-linear inverse flow
B                = neutral matter/anti-flow balance
S                = dark/light spectral shade continuity
E_T              = inverse half-life depletion envelope
kappa            = chiral fourfold circulation
H                = threshold gate
```

## Whole-loop closure condition

The loop passes when the normalized system returns to itself after one bidirectional lap:

```text
W(p,t) = Normalize[M(p,t) + alpha(t)M(-p,t)*]
W(p,t + T_lap) = W(p,t)
sum_p |W(p,t)|^2 = 1
```

The browser harness uses integer mode rates so `T_lap = 1.0` normalized cycle. The Python CLI validates closure error over 97 samples.

## Files added

```text
sure/neutral_creation_loop_test.html   Live visual test harness
sure/nco_loop_engine.js                Browser loop engine
sure/nco_p97_geometry.json             Exact P97 topology data
tools/nco_loop_test.py                 CLI validation test
docs/NEUTRAL_CREATION_LOOP_TEST.md     This document
```

## Browser use

Open:

```text
sure/neutral_creation_loop_test.html
```

or use the MasterControl button:

```text
NCO Loop Test
```

## CLI use

```bash
python3 tools/nco_loop_test.py --seed GARY-UNIVERSE-001 --samples 97
python3 tools/nco_loop_test.py --seed GARY-UNIVERSE-001 --samples 240 --json
```

Expected result: closure error near floating-point zero and `pass: true`.

## Interpretation

This gives SURE a testable loop:

```text
seed -> P97 topology -> matter flow -> anti-space inverse flow -> neutral balance
-> half-life envelope -> chirality gate -> normalized whole -> lap closure receipt
```

If the receipt is stable for the same seed, the loop is deterministic.
